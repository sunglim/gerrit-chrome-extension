gerrit-chrome-extension
=======================

Chrome extension providing a notifier and quick access for incoming Gerrit code reviews.

- How to use:

  Open a option menu on `chrome://extensions`. and set your api-endpoint.
  for example> If you're using `https://hdbgerrit.wdf.sap.corp:8443/#/dashboard/self`. your api-endpoint is `https://hdbgerrit.wdf.sap.corp:8443/`.
